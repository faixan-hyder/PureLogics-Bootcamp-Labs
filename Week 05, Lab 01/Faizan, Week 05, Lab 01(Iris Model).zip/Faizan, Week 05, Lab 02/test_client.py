"""
Test client - run this in a SEPARATE terminal AFTER a server is already running.
    python test_client.py
Edit the URL/port depending on which app you're testing.
"""
import requests

example_features = [5.1, 3.5, 1.4, 0.2]  # Iris setosa example

# Change port depending on which server is running:
# flask_app.py     -> 5000
# fastapi_app.py   -> 8000
# batch_app.py     -> 8001
# version_app.py   -> 8002
# monitoring_app.py-> 8003
# ensemble_app.py  -> 8004
# cache_app.py     -> 8005
# exercise_app.py  -> 8006

url = "http://127.0.0.1:8000/predict"

response = requests.post(url, json={"features": example_features})
print(response.status_code)
print(response.json())
