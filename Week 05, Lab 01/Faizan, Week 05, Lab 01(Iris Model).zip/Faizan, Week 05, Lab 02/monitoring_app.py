"""
MODEL MONITORING
Run separately:
    uvicorn monitoring_app:monitoring_app --reload --port 8003
"""
import time
import uuid
import pickle
import numpy as np
from datetime import datetime
from fastapi import FastAPI, BackgroundTasks, Query
from pydantic import BaseModel
from typing import List


def load_model():
    with open('rf_model.pkl', 'rb') as f:
        return pickle.load(f)


model = load_model()


class IrisFeatures(BaseModel):
    features: List[float]


monitoring_app = FastAPI(title="Model Monitoring API")

prediction_logs = []

model_metrics = {
    "total_requests": 0,
    "successful_predictions": 0,
    "failed_predictions": 0,
    "avg_response_time": 0,
    "prediction_distribution": {0: 0, 1: 0, 2: 0},
    "last_updated": None
}


async def log_prediction(features, prediction, response_time, success):
    global model_metrics

    model_metrics["total_requests"] += 1

    if success:
        model_metrics["successful_predictions"] += 1
        pred_class = prediction[0]
        model_metrics["prediction_distribution"][pred_class] += 1
    else:
        model_metrics["failed_predictions"] += 1

    current_avg = model_metrics["avg_response_time"]
    model_metrics["avg_response_time"] = (
        current_avg * (model_metrics["total_requests"] - 1) + response_time
    ) / model_metrics["total_requests"]

    model_metrics["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    prediction_logs.append({
        "id": str(uuid.uuid4()),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "features": features,
        "prediction": prediction,
        "response_time": response_time,
        "success": success
    })

    if len(prediction_logs) > 100:
        prediction_logs.pop(0)


@monitoring_app.post("/predict")
async def predict_with_monitoring(iris_data: IrisFeatures, background_tasks: BackgroundTasks):
    start_time = time.time()
    success = True
    prediction = None
    response = None

    try:
        features = np.array(iris_data.features).reshape(1, -1)
        prediction = model.predict(features).tolist()
        prediction_proba = model.predict_proba(features).tolist()
        response = {"prediction": prediction, "probability": prediction_proba}
    except Exception as e:
        success = False
        response = {"error": str(e)}

    response_time = time.time() - start_time
    background_tasks.add_task(
        log_prediction,
        iris_data.features,
        prediction if success else None,
        response_time,
        success
    )

    return response


@monitoring_app.get("/metrics")
async def get_metrics():
    return model_metrics


@monitoring_app.get("/logs")
async def get_logs(limit: int = Query(10, ge=1, le=100)):
    return prediction_logs[-limit:]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("monitoring_app:monitoring_app", host="0.0.0.0", port=8003, reload=True)
