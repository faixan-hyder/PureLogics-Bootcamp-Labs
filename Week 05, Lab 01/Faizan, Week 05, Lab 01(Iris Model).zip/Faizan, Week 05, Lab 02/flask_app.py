"""
FLASK DEPLOYMENT
Run separately in its own terminal:
    python flask_app.py
Server runs on http://127.0.0.1:5000
"""
import pickle
import numpy as np
from flask import Flask, request, jsonify

app = Flask(__name__)


def load_model():
    with open('rf_model.pkl', 'rb') as f:
        model = pickle.load(f)
    return model


@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    if not data or 'features' not in data:
        return jsonify({'error': 'No valid features provided'}), 400

    try:
        features = np.array(data['features']).reshape(1, -1)
        model = load_model()
        prediction = model.predict(features).tolist()
        prediction_proba = model.predict_proba(features).tolist()

        return jsonify({
            'prediction': prediction,
            'probability': prediction_proba
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
