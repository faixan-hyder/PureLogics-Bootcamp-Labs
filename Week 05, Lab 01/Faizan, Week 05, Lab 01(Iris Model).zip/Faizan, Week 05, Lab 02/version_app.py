"""
MODEL VERSIONING AND A/B TESTING
Run separately:
    uvicorn version_app:version_app --reload --port 8002
"""
import random
import pickle
import numpy as np
from fastapi import FastAPI, HTTPException, Depends, Query
from pydantic import BaseModel
from typing import List


def load_model():
    with open('rf_model.pkl', 'rb') as f:
        return pickle.load(f)


model = load_model()


class IrisFeatures(BaseModel):
    features: List[float]


version_app = FastAPI(title="Versioned Model API")

models = {"v1": model, "v2": model}

model_registry = {
    "v1": {"version": "1.0.0", "created_at": "2023-01-01", "accuracy": 0.95, "training_data": "iris_dataset_2022"},
    "v2": {"version": "2.0.0", "created_at": "2023-06-01", "accuracy": 0.97, "training_data": "iris_dataset_2023"},
}

model_weights = {"v1": 0.7, "v2": 0.3}


def get_model_version(ab_test: bool = Query(False, description="Enable A/B testing")):
    if ab_test:
        versions = list(model_weights.keys())
        weights = list(model_weights.values())
        return random.choices(versions, weights=weights, k=1)[0]
    return "v2"


@version_app.post("/predict")
async def predict_with_version(
    iris_data: IrisFeatures,
    version: str = Query(None, description="Model version (v1 or v2)"),
    model_version: str = Depends(get_model_version)
):
    selected_version = version if version else model_version

    if selected_version not in models:
        raise HTTPException(status_code=404, detail=f"Model version {selected_version} not found")

    selected_model = models[selected_version]
    features = np.array(iris_data.features).reshape(1, -1)
    prediction = selected_model.predict(features).tolist()
    prediction_proba = selected_model.predict_proba(features).tolist()

    return {
        "prediction": prediction,
        "probability": prediction_proba,
        "model_version": selected_version,
        "model_info": model_registry[selected_version]
    }


@version_app.get("/models")
async def get_models():
    return model_registry


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("version_app:version_app", host="0.0.0.0", port=8002, reload=True)
