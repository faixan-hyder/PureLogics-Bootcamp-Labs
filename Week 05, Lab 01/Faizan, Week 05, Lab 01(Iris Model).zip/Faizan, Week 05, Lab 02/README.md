# Iris Model Deployment Lab — Local Setup (VS Code)

Yeh notebook asal mein **Google Colab** ke liye likha gaya tha, jahan har cell
alag context mein "conceptually" chalta hai. Local VS Code Jupyter mein
**Flask** (`app.run()`) aur **FastAPI** (`uvicorn.run()`) dono blocking servers
hain — ek hi kernel/process mein dono ko chalana conflict aur error deta hai.

**Solution:** har server ko apni alag `.py` file mein rakho aur **alag-alag
terminal tabs** se run karo. Isi tarah asal duniya mein bhi APIs deploy hoti hain.

## Setup (ek dafa)

```bash
pip install flask fastapi uvicorn scikit-learn numpy pandas python-multipart requests
python train_model.py
```

Yeh `rf_model.pkl` bana dega jo baaki saari files use karti hain.

## Har server ko alag terminal mein chalao

| File | Command | Port |
|---|---|---|
| `flask_app.py` | `python flask_app.py` | 5000 |
| `fastapi_app.py` | `python fastapi_app.py` | 8000 |
| `batch_app.py` | `uvicorn batch_app:batch_app --reload --port 8001` | 8001 |
| `version_app.py` | `uvicorn version_app:version_app --reload --port 8002` | 8002 |
| `monitoring_app.py` | `uvicorn monitoring_app:monitoring_app --reload --port 8003` | 8003 |
| `ensemble_app.py` | `uvicorn ensemble_app:ensemble_app --reload --port 8004` | 8004 |
| `cache_app.py` | `uvicorn cache_app:cache_app --reload --port 8005` | 8005 |
| `exercise_app.py` (solved) | `uvicorn exercise_app:app --reload --port 8006` | 8006 |

Sirf **ek waqt mein ek server** chalao (jab tak alag ports use na karo, jo yahan
already alag rakhe hain — chaho to sab ek saath bhi chala sakte ho!).

## Test karna

1. Koi bhi server upar wale command se chalao.
2. `test_client.py` mein URL/port set karo, phir **naya terminal** khol kar:
   ```bash
   python test_client.py
   ```
   Ya Postman use karo (POST request, JSON body: `{"features": [5.1, 3.5, 1.4, 0.2]}`).
3. FastAPI apps ke liye Swagger UI bhi milta hai: `http://127.0.0.1:<port>/docs`

## Cache/Auth app test

`cache_app.py` ko header ke sath test karo:
```
X-API-Key: your-secret-api-key
```

## Note

VS Code ke Jupyter cells mein in servers ko run **na karo** — wo cell ko hamesha
ke liye block kar dega (kernel busy reh jayega) aur agla cell chalane par purana
server chalta rahega jab tak kernel restart na karo. Terminal se run karna hi
sahi tareeqa hai.
