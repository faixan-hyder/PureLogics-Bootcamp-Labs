"""
FASTAPI DEPLOYMENT (basic)
Run separately in its own terminal:
    uvicorn fastapi_app:app_fastapi --reload --port 8000
Or simply:
    python fastapi_app.py
Server runs on http://127.0.0.1:8000  (docs at /docs)
"""
import pickle
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import uvicorn
from sklearn.datasets import load_iris


def load_model():
    with open('rf_model.pkl', 'rb') as f:
        model = pickle.load(f)
    return model


feature_names = load_iris().feature_names
model = load_model()


class IrisFeatures(BaseModel):
    features: List[float]

    class Config:
        json_schema_extra = {
            "example": {"features": [5.1, 3.5, 1.4, 0.2]}
        }


class PredictionResponse(BaseModel):
    prediction: List[int]
    probability: List[List[float]]
    feature_importance: Optional[Dict[str, float]] = None


app_fastapi = FastAPI(
    title="Iris Classifier API",
    description="API for classifying iris flowers using a RandomForest model",
    version="1.0.0"
)


@app_fastapi.post("/predict", response_model=PredictionResponse)
async def predict_iris(iris_data: IrisFeatures):
    try:
        features = np.array(iris_data.features).reshape(1, -1)
        prediction = model.predict(features).tolist()
        prediction_proba = model.predict_proba(features).tolist()

        feature_importance = {}
        if hasattr(model, 'feature_importances_'):
            for i, importance in enumerate(model.feature_importances_):
                feature_name = feature_names[i] if i < len(feature_names) else f"feature_{i}"
                feature_importance[feature_name] = float(importance)

        return {
            "prediction": prediction,
            "probability": prediction_proba,
            "feature_importance": feature_importance
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app_fastapi.get("/health")
async def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    uvicorn.run("fastapi_app:app_fastapi", host="0.0.0.0", port=8000, reload=True)
