"""
Run this file FIRST, once, to train and save the model.
    python train_model.py
"""
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_iris


def create_model():
    iris = load_iris()
    X = iris.data
    y = iris.target

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    with open('rf_model.pkl', 'wb') as f:
        pickle.dump(model, f)

    return model, iris.feature_names


if __name__ == "__main__":
    model, feature_names = create_model()
    print("Model trained and saved as rf_model.pkl")
    print("Feature names:", feature_names)
