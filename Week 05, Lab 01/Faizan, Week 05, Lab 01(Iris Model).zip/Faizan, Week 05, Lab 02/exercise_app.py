"""
EXERCISE (SOLVED): Prediction API with Rate Limiting + Performance Metrics
Run separately:
    uvicorn exercise_app:app --reload --port 8006
"""
import time
import pickle
import numpy as np
from collections import defaultdict, deque
from datetime import datetime
from fastapi import FastAPI, Request, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_iris

# --- Model ---
iris = load_iris()
X, y = iris.data, iris.target
iris_model = RandomForestClassifier(n_estimators=100, random_state=42)
iris_model.fit(X, y)
feature_names = iris.feature_names


class IrisFeatures(BaseModel):
    features: List[float]


# --- PART 1: Rate limiter ---
class RateLimiter:
    def __init__(self, requests_limit: int = 5, window_seconds: int = 60):
        self.requests_limit = requests_limit
        self.window_seconds = window_seconds
        self.client_requests = defaultdict(deque)

    def is_rate_limited(self, client_id: str) -> bool:
        now = time.time()
        requests = self.client_requests[client_id]
        while requests and now - requests[0] > self.window_seconds:
            requests.popleft()
        return len(requests) >= self.requests_limit

    def add_request(self, client_id: str) -> None:
        self.client_requests[client_id].append(time.time())


app = FastAPI(title="Iris Model API with Rate Limiting")
rate_limiter = RateLimiter(requests_limit=5, window_seconds=60)


async def check_rate_limit(request: Request):
    client_id = request.client.host if request.client else "unknown"
    if rate_limiter.is_rate_limited(client_id):
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Try again later.")
    rate_limiter.add_request(client_id)


# --- PART 2: Performance tracking ---
performance_metrics = {
    "total_requests": 0,
    "total_response_time": 0.0,
    "avg_response_time": 0.0,
    "prediction_distribution": {0: 0, 1: 0, 2: 0},
    "last_updated": None,
}


async def update_metrics(features, prediction, response_time):
    performance_metrics["total_requests"] += 1
    performance_metrics["total_response_time"] += response_time
    performance_metrics["avg_response_time"] = (
        performance_metrics["total_response_time"] / performance_metrics["total_requests"]
    )
    performance_metrics["prediction_distribution"][prediction] += 1
    performance_metrics["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# --- PART 3: Prediction endpoint ---
@app.post("/predict")
async def predict(iris_data: IrisFeatures, request: Request, rate_limit: None = Depends(check_rate_limit)):
    start_time = time.time()
    features = np.array(iris_data.features).reshape(1, -1)
    prediction = int(iris_model.predict(features)[0])
    probability = iris_model.predict_proba(features).tolist()
    response_time = time.time() - start_time

    await update_metrics(iris_data.features, prediction, response_time)

    return {
        "prediction": prediction,
        "probability": probability,
        "response_time_seconds": response_time
    }


# --- PART 4: Dashboard endpoint ---
@app.get("/dashboard")
async def dashboard():
    return performance_metrics


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8006)
