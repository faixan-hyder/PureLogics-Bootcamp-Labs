"""
BATCH PREDICTION API
Run separately:
    uvicorn batch_app:batch_app --reload --port 8001
"""
import io
import time
import pickle
import asyncio
import pandas as pd
from fastapi import FastAPI, BackgroundTasks, File, UploadFile, HTTPException


def load_model():
    with open('rf_model.pkl', 'rb') as f:
        return pickle.load(f)


model = load_model()
batch_app = FastAPI(title="Batch Prediction API")

job_queue = {}


async def process_batch_job(job_id: str, file_content: bytes):
    try:
        await asyncio.sleep(2)
        df = pd.read_csv(io.BytesIO(file_content))

        predictions = []
        for _, row in df.iterrows():
            features = row.values.reshape(1, -1)
            pred = model.predict(features)[0]
            predictions.append(int(pred))

        job_queue[job_id] = {
            "status": "completed",
            "predictions": predictions,
            "processed_at": time.strftime("%Y-%m-%d %H:%M:%S")
        }
    except Exception as e:
        job_queue[job_id] = {
            "status": "failed",
            "error": str(e),
            "processed_at": time.strftime("%Y-%m-%d %H:%M:%S")
        }


@batch_app.post("/batch-predict")
async def create_batch_job(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    try:
        job_id = f"job_{int(time.time())}"
        file_content = await file.read()

        job_queue[job_id] = {
            "status": "processing",
            "submitted_at": time.strftime("%Y-%m-%d %H:%M:%S")
        }

        background_tasks.add_task(process_batch_job, job_id, file_content)
        return {"job_id": job_id, "status": "submitted"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@batch_app.get("/batch-status/{job_id}")
async def get_batch_status(job_id: str):
    if job_id not in job_queue:
        raise HTTPException(status_code=404, detail="Job not found")
    return job_queue[job_id]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("batch_app:batch_app", host="0.0.0.0", port=8001, reload=True)
