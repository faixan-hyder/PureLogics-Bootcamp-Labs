"""
MODEL SERVING WITH CACHING + API KEY AUTH
Run separately:
    uvicorn cache_app:cache_app --reload --port 8005

Test with header:  X-API-Key: your-secret-api-key
"""
import time
import pickle
import functools
import numpy as np
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import APIKeyHeader
from pydantic import BaseModel
from typing import List


def load_model():
    with open('rf_model.pkl', 'rb') as f:
        return pickle.load(f)


model = load_model()


class IrisFeatures(BaseModel):
    features: List[float]


cache_app = FastAPI(title="Model API with Caching")

prediction_cache = {}
CACHE_TTL = 300

API_KEY = "your-secret-api-key"
api_key_header = APIKeyHeader(name="X-API-Key")


def verify_api_key(api_key: str = Depends(api_key_header)):
    if api_key != API_KEY:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key")
    return api_key


def cache_prediction(ttl=CACHE_TTL):
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            if 'iris_data' in kwargs:
                features_tuple = tuple(kwargs['iris_data'].features)
                cache_key = f"prediction_{features_tuple}"

                if cache_key in prediction_cache:
                    result, timestamp = prediction_cache[cache_key]
                    if time.time() - timestamp < ttl:
                        return {**result, "cache_hit": True}

            result = await func(*args, **kwargs)

            if 'iris_data' in kwargs:
                prediction_cache[cache_key] = (result, time.time())

            return {**result, "cache_hit": False}
        return wrapper
    return decorator


@cache_app.post("/predict")
@cache_prediction(ttl=300)
async def predict_with_cache(iris_data: IrisFeatures, api_key: str = Depends(verify_api_key)):
    features = np.array(iris_data.features).reshape(1, -1)
    time.sleep(1)
    prediction = model.predict(features).tolist()
    prediction_proba = model.predict_proba(features).tolist()

    return {
        "prediction": prediction,
        "probability": prediction_proba,
    }


@cache_app.get("/cache-info")
async def get_cache_info(api_key: str = Depends(verify_api_key)):
    current_time = time.time()
    active_cache_entries = sum(
        1 for _, (_, timestamp) in prediction_cache.items()
        if current_time - timestamp < CACHE_TTL
    )

    return {
        "total_entries": len(prediction_cache),
        "active_entries": active_cache_entries,
        "cache_ttl": CACHE_TTL
    }


@cache_app.post("/clear-cache")
async def clear_cache(api_key: str = Depends(verify_api_key)):
    prediction_cache.clear()
    return {"message": "Cache cleared successfully"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("cache_app:cache_app", host="0.0.0.0", port=8005, reload=True)
