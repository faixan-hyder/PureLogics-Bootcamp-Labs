"""
ENSEMBLE MODEL API
Run separately:
    uvicorn ensemble_app:ensemble_app --reload --port 8004
"""
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.datasets import load_iris


class IrisFeatures(BaseModel):
    features: List[float]


def create_ensemble_models():
    iris = load_iris()
    X, y = iris.data, iris.target

    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    lr_model = LogisticRegression(random_state=42)
    svm_model = SVC(probability=True, random_state=42)

    rf_model.fit(X, y)
    lr_model.fit(X, y)
    svm_model.fit(X, y)

    return {
        "random_forest": rf_model,
        "logistic_regression": lr_model,
        "svm": svm_model
    }, iris.feature_names


ensemble_models, _ = create_ensemble_models()

ensemble_app = FastAPI(title="Ensemble Model API")

model_weights = {
    "random_forest": 0.5,
    "logistic_regression": 0.3,
    "svm": 0.2
}


@ensemble_app.post("/predict")
async def predict_ensemble(iris_data: IrisFeatures):
    features = np.array(iris_data.features).reshape(1, -1)

    predictions = {}
    probabilities = {}

    for model_name, model in ensemble_models.items():
        predictions[model_name] = int(model.predict(features)[0])
        probabilities[model_name] = model.predict_proba(features)[0].tolist()

    ensemble_proba = np.zeros(3)
    for model_name, proba in probabilities.items():
        weight = model_weights.get(model_name, 1 / len(ensemble_models))
        ensemble_proba += weight * np.array(proba)

    final_prediction = int(np.argmax(ensemble_proba))

    return {
        "ensemble_prediction": final_prediction,
        "ensemble_probability": ensemble_proba.tolist(),
        "individual_predictions": predictions,
        "individual_probabilities": probabilities
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ensemble_app:ensemble_app", host="0.0.0.0", port=8004, reload=True)
